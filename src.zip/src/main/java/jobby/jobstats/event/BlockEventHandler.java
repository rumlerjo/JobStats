package jobby.jobstats.event;

import jobby.jobstats.stat.StatManager;
import jobby.jobstats.stat.StatType;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.CropBlock;

public class BlockEventHandler {
    public static void register() {
        PlayerBlockBreakEvents.AFTER.register((level, player, pos, state, blockEntity) -> {
            if (player.isCreative()) return;

            ItemStack mainHand = player.getMainHandItem();
            if (mainHand.isEmpty()) return;

            // Track Crops Harvested
            if (state.getBlock() instanceof CropBlock) {
                if (mainHand.has(DataComponents.TOOL)) {
                    StatManager.incrementStat(mainHand, StatType.CROPS_HARVESTED, 1);
                }
            } 
            // Track Blocks Mined
            else if (mainHand.has(DataComponents.TOOL)) {
                // Only count if the tool is the correct one to get drops from this block
                if (mainHand.isCorrectToolForDrops(state)) {
                    StatManager.incrementStat(mainHand, StatType.BLOCKS_MINED, 1);
                }
            }
        });
    }
}