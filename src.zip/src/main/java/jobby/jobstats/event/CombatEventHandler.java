package jobby.jobstats.event;

import jobby.jobstats.stat.StatManager;
import jobby.jobstats.stat.StatType;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityCombatEvents;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

public class CombatEventHandler {
    public static void register() {
        // Added the damageSource parameter to match the functional interface signature
        ServerEntityCombatEvents.AFTER_KILLED_OTHER_ENTITY.register((level, entity, killedEntity, damageSource) -> {
            if (entity instanceof Player player) {
                ItemStack weapon = player.getMainHandItem();
                
                // Track Kills if holding a weapon or a tool (like an axe)
                if (weapon.has(DataComponents.WEAPON) || weapon.has(DataComponents.TOOL)) {
                    StatManager.incrementStat(weapon, StatType.MOB_KILLS, 1);
                }
            }
        });
    }
}