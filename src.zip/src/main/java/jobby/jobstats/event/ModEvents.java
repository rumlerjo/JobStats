package jobby.jobstats.event;

public class ModEvents {
    public static void initialize() {
        BlockEventHandler.register();
        CombatEventHandler.register();
    }
}