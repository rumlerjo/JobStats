package jobby.jobstats;

import jobby.jobstats.config.ColorConfig;
import jobby.jobstats.event.ModEvents;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JobStats implements ModInitializer {
    public static final String MOD_ID = "jobstats";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing JobStats Configuration...");
        // Load the config first
        ColorConfig.load();
        
        LOGGER.info("Registering JobStats Events...");
        ModEvents.initialize();
    }
}