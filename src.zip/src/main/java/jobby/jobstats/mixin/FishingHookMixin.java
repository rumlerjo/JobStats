package jobby.jobstats.mixin;

import jobby.jobstats.stat.StatManager;
import jobby.jobstats.stat.StatType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.FishingHook;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(FishingHook.class)
public abstract class FishingHookMixin {
    @Inject(method = "retrieve", at = @At("RETURN"))
    private void jobstats$onFishCaught(ItemStack stack, CallbackInfoReturnable<Integer> cir) {
        FishingHook hook = (FishingHook) (Object) this;
        Player owner = hook.getPlayerOwner();
        
        // A return value > 0 from retrieve() indicates the rod pulled an entity or item successfully
        if (owner != null && !owner.level().isClientSide() && cir.getReturnValue() > 0) {
            StatManager.incrementStat(stack, StatType.FISH_CAUGHT, 1);
        }
    }
}