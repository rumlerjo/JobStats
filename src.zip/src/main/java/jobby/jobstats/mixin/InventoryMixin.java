package jobby.jobstats.mixin;

import jobby.jobstats.stat.StatManager;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Inventory.class)
public class InventoryMixin {

    @Shadow @Final public Player player;

    @Inject(method = "add(Lnet/minecraft/world/item/ItemStack;)Z", at = @At("HEAD"))
    private void jobstats$onInsertStack(ItemStack stack, CallbackInfoReturnable<Boolean> cir) {
        if (this.player != null && !this.player.level().isClientSide()) {
            StatManager.setOwnership(stack, this.player.getName().getString());
        }
    }

    @Inject(method = "setItem", at = @At("HEAD"))
    private void jobstats$onSetStack(int index, ItemStack stack, CallbackInfo ci) {
        if (this.player != null && !this.player.level().isClientSide()) {
            StatManager.setOwnership(stack, this.player.getName().getString());
        }
    }
}