package jobby.jobstats.mixin;

import jobby.jobstats.stat.StatManager;
import jobby.jobstats.stat.StatType;
import net.minecraft.tags.ItemTags; // Added ItemTags import
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ItemStack.class)
public abstract class ItemStackMixin {

    // 1. Logs Stripped
    @Inject(method = "useOn", at = @At("RETURN"))
    private void jobstats$onUseOnBlock(UseOnContext context, CallbackInfoReturnable<InteractionResult> cir) {
        if (cir.getReturnValue().consumesAction() && !context.getLevel().isClientSide()) {
            ItemStack stack = (ItemStack) (Object) this;
            
            // Replaced Items.AXE with ItemTags.AXES
            if (stack.is(ItemTags.AXES)) {
                StatManager.incrementStat(stack, StatType.LOGS_STRIPPED, 1);
            }
        }
    }

    // 2. Sheep Sheared (Backup via Item Interaction)
    @Inject(method = "interactLivingEntity", at = @At("RETURN"))
    private void jobstats$onInteractEntity(Player player, LivingEntity entity, InteractionHand hand, CallbackInfoReturnable<InteractionResult> cir) {
        if (cir.getReturnValue().consumesAction() && !player.level().isClientSide()) {
            ItemStack stack = (ItemStack) (Object) this;
            if (stack.is(Items.SHEARS)) {
                StatManager.incrementStat(stack, StatType.SHEEP_SHEARED, 1);
            }
        }
    }

    // 3. Tridents Thrown and Arrows Shot
    @Inject(method = "releaseUsing", at = @At("HEAD"))
    private void jobstats$onReleaseUsing(Level level, LivingEntity entity, int timeLeft, CallbackInfo ci) {
        if (!level.isClientSide()) {
            ItemStack stack = (ItemStack) (Object) this;
            int duration = stack.getUseDuration(entity) - timeLeft;
            
            if (stack.is(Items.TRIDENT) && duration >= 10) {
                StatManager.incrementStat(stack, StatType.TRIDENTS_THROWN, 1);
            } else if (stack.is(Items.BOW) || stack.is(Items.CROSSBOW)) {
                StatManager.incrementStat(stack, StatType.ARROWS_SHOT, 1);
            }
        }
    }
}