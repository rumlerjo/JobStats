package jobby.jobstats.mixin;

import jobby.jobstats.stat.StatManager;
import jobby.jobstats.stat.StatType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Player.class)
public abstract class PlayerMixin {
    
    @Unique
    private int flightTickCounter = 0;

    @Inject(method = "tick", at = @At("TAIL"))
    private void jobstats$trackElytraFlight(CallbackInfo ci) {
        Player player = (Player) (Object) this;
        if (!player.level().isClientSide() && player.isFallFlying()) {
            flightTickCounter++;
            
            if (flightTickCounter >= 20) {
                ItemStack chestItem = player.getItemBySlot(EquipmentSlot.CHEST);
                
                // Replaces the old 'instanceof ElytraItem' check
                if (chestItem.has(DataComponents.GLIDER)) {
                    StatManager.incrementStat(chestItem, StatType.ELYTRA_FLIGHT, 1);
                }
                flightTickCounter = 0;
            }
        } else {
            flightTickCounter = 0;
        }
    }

    @Inject(method = "crit", at = @At("HEAD"))
    private void jobstats$onCriticalStrike(Entity entityHit, CallbackInfo ci) {
        Player player = (Player) (Object) this;
        if (!player.level().isClientSide()) {
            ItemStack weapon = player.getMainHandItem();
            StatManager.incrementStat(weapon, StatType.CRITICAL_STRIKES, 1);
        }
    }

    @Inject(method = "drop(Lnet/minecraft/world/item/ItemStack;ZZ)Lnet/minecraft/world/entity/item/ItemEntity;", at = @At("HEAD"))
    private void jobstats$onDropItem(ItemStack stack, boolean includeThrowerName, boolean retainOwnership, CallbackInfoReturnable<ItemEntity> cir) {
        Player player = (Player) (Object) this;
        if (!player.level().isClientSide()) {
            StatManager.setOwnership(stack, player.getName().getString());
        }
    }
}