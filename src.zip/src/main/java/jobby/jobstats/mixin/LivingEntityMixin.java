package jobby.jobstats.mixin;

import jobby.jobstats.stat.StatManager;
import jobby.jobstats.stat.StatType;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {

    @Inject(method = "hurt", at = @At("RETURN"))
    private void jobstats$onHurt(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValue() && source.getEntity() instanceof Player player) {
            ItemStack weapon = player.getMainHandItem();
            if (!weapon.isEmpty()) {
                StatManager.incrementStat(weapon, StatType.DAMAGE_DEALT, Math.round(amount));
            }
        }
    }

    @Inject(method = "hurtArmor", at = @At("HEAD"))
    private void jobstats$onHurtArmor(DamageSource source, float amount, CallbackInfo ci) {
        LivingEntity entity = (LivingEntity) (Object) this;
        if (entity instanceof Player && amount > 0) {
            
            // Replaced getArmorSlots() with manual iteration of standard equipment slots
            EquipmentSlot[] armorSlots = new EquipmentSlot[]{
                EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
            };
            
            for (EquipmentSlot slot : armorSlots) {
                ItemStack armorPiece = entity.getItemBySlot(slot);
                if (!armorPiece.isEmpty()) {
                    StatManager.incrementStat(armorPiece, StatType.ARMOR_DAMAGE, Math.round(amount));
                }
            }
        }
    }

    @Inject(method = "hurtCurrentlyUsedShield", at = @At("HEAD"))
    private void jobstats$onHurtShield(float amount, CallbackInfo ci) {
        LivingEntity entity = (LivingEntity) (Object) this;
        if (entity instanceof Player && amount > 0) {
            ItemStack activeItem = entity.getUseItem();
            if (activeItem.is(Items.SHIELD)) {
                StatManager.incrementStat(activeItem, StatType.ARMOR_DAMAGE, Math.round(amount));
            }
        }
    }
}